# Portfolio Project

This is a Django portfolio site. Steps to run locally and prepare static assets for production:

1. Create and activate virtualenv

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. Run migrations and collect static

```bash
python manage.py migrate
python manage.py collectstatic
```

3. Run server

```bash
python manage.py runserver
```

Notes for production:
- `STATIC_ROOT` is configured; run `collectstatic` and serve `staticfiles/` with your webserver or via WhiteNoise.
- See `portfolio_project/settings.py` for WhiteNoise middleware and storage configuration.
 
Production checklist:
- Set environment variables (see `.env.example`) and keep `DJANGO_DEBUG=False` in production.
- Install production dependencies and run `python manage.py collectstatic`.
- Use `Gunicorn` (Procfile included) or a WSGI process manager behind a reverse proxy.
- Optionally build the included `Dockerfile` for containerized deployments.

Example production commands (after env vars are set):
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
gunicorn portfolio_project.wsgi:application --bind 0.0.0.0:8000
```

Systemd & Nginx deployment steps (example):

```bash
# 1. Create a virtualenv in the project `env/` directory and install requirements
python3 -m venv env
source env/bin/activate
pip install -r requirements.txt

# 2. Collect static and migrate
python manage.py migrate
python manage.py collectstatic --noinput

# 3. Copy systemd unit and reload
sudo cp gunicorn/gunicorn.service /etc/systemd/system/gunicorn.service
sudo systemctl daemon-reload
sudo systemctl enable gunicorn
sudo systemctl start gunicorn

# 4. Copy nginx config and enable
sudo cp nginx/portfolio_project.conf /etc/nginx/sites-available/portfolio_project
sudo ln -s /etc/nginx/sites-available/portfolio_project /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl enable nginx
sudo systemctl restart nginx
```

Notes:
- Ensure `/home/ubuntu/portfolio_project` (WorkingDirectory) matches your actual deployment path.
- Replace `your_domain.com` and certificate paths in the Nginx config before enabling.
- For HTTPS get certificates with Let's Encrypt: `sudo certbot --nginx -d your_domain.com -d www.your_domain.com`.# unknown
 - For HTTPS get certificates with Let's Encrypt: `sudo certbot --nginx -d your_domain.com -d www.your_domain.com`.

Deploying to Render.com
-----------------------

You can deploy this repository to Render.com (recommended for quick managed deployment). I added a `render.yaml` that describes a Python web service — Render will pick this up if you connect the GitHub repo.

Steps on Render:

1. Push this repository to GitHub (you must grant Render access to the repo). See the Git section below for pushing.
2. On Render, create a new Web Service and connect your GitHub repository. Select `portfolio-project` (or let Render read `render.yaml`).
3. Set environment variables in Render Dashboard (Environment > Environment Variables):
	- `DJANGO_SETTINGS_MODULE=portfolio_project.settings_production`
	- `DJANGO_SECRET_KEY` (strong secret)
	- `DJANGO_DEBUG=False`
	- `DJANGO_ALLOWED_HOSTS=yourdomain.com www.your_domain.com` (space-separated)
	- Database vars (if using PostgreSQL): `DATABASE_URL` etc.
4. Render will run the `buildCommand` from `render.yaml` (install deps). Ensure `collectstatic` is run as part of your build or add `python manage.py collectstatic --noinput` to the `buildCommand` if desired.
	Example `buildCommand` on Render dashboard:
	```bash
	pip install -r requirements.txt && python manage.py migrate && python manage.py collectstatic --noinput
	```
5. Start command is `gunicorn portfolio_project.wsgi:application --bind 0.0.0.0:$PORT` (already in `render.yaml`).

Notes for static files on Render:
- We use WhiteNoise to serve static files; `STATIC_ROOT` is configured as `staticfiles/`. Make sure `collectstatic` is executed during build.

Pushing to GitHub (SSH preferred)
---------------------------------

I attempted to push to your GitHub repo but the environment lacks your SSH credentials. Please add your SSH key to GitHub and then push from this machine or locally. Steps:

1. Generate an SSH key (if you don't have one):
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
```

2. Start ssh-agent and add the key:
```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

3. Copy the public key and add it on GitHub (Settings → SSH and GPG keys):
```bash
cat ~/.ssh/id_ed25519.pub
```

4. Test the connection and push:
```bash
ssh -T git@github.com
git push -u origin main
```

If you'd rather I attempt the push here after you add the SSH key, tell me and I'll retry. Alternatively, provide a Personal Access Token (PAT) and I can push via HTTPS (less secure). 
